import { State as UserState } from './actions/user.actions';


export interface AppState {
    user: UserState;
}
